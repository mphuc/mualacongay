<?php
$skins = array(
    "Cupertino" => "cupertino",
	"Mountain View" => "mountainview",
	"Mountain View (Dark)" => "mountainview_dark"
);
?>