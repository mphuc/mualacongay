<?php
$languages = array(
    "Català" => "ca",
	"Česky" => "cs",
	"Dansk" => "da",
	"Deutsch" => "de",
    "Ελληνικά" => "el",	
	"English" => "en",
	"Español" => "es",
	"Français" => "fr",
	"Italiano" => "it",
	"Nederlands" => "nl",
	"Русский" => "ru",
	"Српски / Srpski" => "rs",
	"Svenska" => "se"
);
?>