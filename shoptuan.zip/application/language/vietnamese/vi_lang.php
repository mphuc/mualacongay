<?php 
# Header 
$lang['username'] = "Tên user"; 
$lang['password'] = "Mật khẩu"; 
$lang['passconf'] = "Xác nhận Mật khẩu"; 
$lang['matches'] = "Trường '%s' không khớp với trường '%s'."; 
$lang['required'] = "Trường '%s' là bắt buộc."; 
$lang['invalid-email'] = "Email này không hợp lệ.";
$lang['min_length'] = "Độ dài tối thiểu %s ký tự.";
$lang['max_length'] = "Độ dài tối đa %s ký tự.";

?>