<?php if (!defined('BASEPATH')) exit('No direct script access allowed');


$config['appId']   = '822602221138459';
$config['secret']  = '546195d546afa6cf25bcf6320b437d29';

?>
